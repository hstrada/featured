package io.example.toggled

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ToggledApplicationTests {

	@Test
	fun contextLoads() {
	}

}
