package io.example.featured

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FeaturedApplicationTests {

	@Test
	fun contextLoads() {
	}

}
